﻿using System;
using System.Net.Http.Headers;
using Microsoft.Extensions.Options;
using vector_code.Interfaces;
using vector_code.Repositories.Models;
using vector_code.Settings;

namespace vector_code.Implementations
{
    public class HttpChatApiClient : IChatApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly AiApiSettings _chatSettings;

        public HttpChatApiClient(HttpClient httpClient, IOptions<AiApiSettings> chatOptions)
        {
            _chatSettings = chatOptions.Value;
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri(_chatSettings.BaseUrl);
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _chatSettings.ApiKey);
        }

        public async Task<string> SendMessageAsync(string userMessage)
        {
            var payload = new OpenApiRequest()
            {
                Model = _chatSettings.DefaultModel,
                Messages = new List<OpenApiResponse.Message> { new() { Role = "user", Content = userMessage } },
                MaxTokens = 1000
            };

            var response = await _httpClient.PostAsJsonAsync("", payload);
            response.EnsureSuccessStatusCode();

            var body = await response.Content.ReadFromJsonAsync<OpenApiResponse?>();
            if (body?.Choices != null && body.Choices.Length > 0)
            {
                return body.Choices[0].Message.Content;
            }

            return await response.Content.ReadAsStringAsync();
        }
    }

}