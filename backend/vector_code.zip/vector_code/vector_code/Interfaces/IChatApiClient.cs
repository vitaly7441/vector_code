﻿using System;
using Microsoft.OpenApi.Models;

namespace vector_code.Interfaces
{
    public interface IChatApiClient
    {
        //Task<string> SendMessageAsync(string userMessage, IEnumerable<OpenApiResponse.Message> history);
        Task<string> SendMessageAsync(string userMessage);
    }
}

