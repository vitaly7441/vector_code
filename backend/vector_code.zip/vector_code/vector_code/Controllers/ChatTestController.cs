﻿using System;
using Microsoft.AspNetCore.Mvc;
using vector_code.Interfaces;
using vector_code.Implementations;

namespace vector_code.Controllers
{
    [ApiController]
    [Route("api/chat")]
    public class ChatTestController : ControllerBase
    {
        private readonly IChatApiClient chatApiClient;
        public ChatTestController(IChatApiClient chatApiClient) {
            this.chatApiClient = chatApiClient;
        }

        [HttpPost("test")]
        public async Task<IActionResult> Test([FromBody] ChatTestRequest request)
        {
            var answer = await chatApiClient.SendMessageAsync(request.Message);
            return Ok(new { answer });
        }
    }

    public record ChatTestRequest(string Message);

}

