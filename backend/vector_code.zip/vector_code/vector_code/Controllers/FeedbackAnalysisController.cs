﻿using System;
using System.Text.Json;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using vector_code.DTO;
using vector_code.Interfaces;
using System.Text;

namespace vector_code.Controllers
{
	public class FeedbackAnalysisController: ControllerBase
    {
        private readonly IChatApiClient _chatApiClient;

        public FeedbackAnalysisController(IChatApiClient chatApiClient)
        {
            _chatApiClient = chatApiClient;
        }

        [HttpPost("analyze")]
        public async Task<IActionResult> AnalyzeReviews([FromBody] FeedbackRequest request)
        {
            if (request.Reviews == null || !request.Reviews.Any())
            {
                return BadRequest("Список отзывов не может быть пустым");
            }

            var jsonInput = JsonSerializer.Serialize(request, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            try
            {
                string appDirectory = AppContext.BaseDirectory;
                string promptFilePath = Path.Combine(appDirectory, "Prompt.txt");

                if (!System.IO.File.Exists(promptFilePath))
                {
                    return StatusCode(500, $"Файл Prompt.txt не найден. Проверьте, что он находится в: {promptFilePath}");
                }

                var basePrompt = await System.IO.File.ReadAllTextAsync(promptFilePath, Encoding.UTF8);

                var prompt = $"{basePrompt}. Входные данные:{jsonInput}";
                
                var response = await _chatApiClient.SendMessageAsync(prompt);
                //var analysisResult = JsonSerializer.Deserialize<AnalysisResult>(response);
                return Ok(new
                {
                    success = true,
                    data = response
                });
            }
            catch (JsonException ex)
            {
                return StatusCode(500, $"Ошибка парсинга JSON от AI: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Ошибка при анализе отзывов: {ex.Message}");
            }
        }
    }
}

