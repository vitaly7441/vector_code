﻿using vector_code.Implementations;
using vector_code.Interfaces;
using vector_code.Settings;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpClient<IChatApiClient, HttpChatApiClient>();

builder.Services.AddHttpClient("WildberriesClient", client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
    client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");
});

builder.Services.Configure<AiApiSettings>(
        builder.Configuration.GetSection("AiApi"));

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins(
            "http://localhost:63342",  // Порт вашего фронтенда
            "http://127.0.0.1:63342") // Альтернативный localhost
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials(); // Если нужны куки/авторизация
    });
});

builder.Services.AddHttpClient<IChatApiClient, HttpChatApiClient>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors("AllowFrontend");

app.UseAuthorization();

app.MapControllers();

app.Run();

