﻿using System;
using Microsoft.AspNetCore.Mvc.ViewEngines;

namespace vector_code.DTO
{
    public class FeedbackRequest
	{
        public List<Feedback> Reviews { get; set; } = new();
    }
}

