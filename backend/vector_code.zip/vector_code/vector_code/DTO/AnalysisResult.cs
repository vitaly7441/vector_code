﻿using System;
namespace vector_code.DTO
{
    public class AnalysisResult
    {
        public AmountClass Amount { get; set; } = new();
        public PercentageClass Percentage { get; set; } = new();
        public List<string> MostCommonWords { get; set; } = new();
        public List<string> TopIssues { get; set; } = new();
        public List<string> ImprovementRecommendations { get; set; } = new();
    }

    public class AmountClass
    {
        public int Positive { get; set; }
        public int Negative { get; set; }
        public int Neutral { get; set; }
        public int Question { get; set; }
    }

    public class PercentageClass
    {
        public double Positive { get; set; }
        public double Negative { get; set; }
        public double Neutral { get; set; }
        public double Question { get; set; }
    }
}

