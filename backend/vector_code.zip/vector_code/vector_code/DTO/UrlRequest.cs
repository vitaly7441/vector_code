﻿using System;
namespace vector_code.DTO
{
    public class UrlRequest
    {
        public string Url { get; set; }
    }
}

