﻿using System;
namespace vector_code.DTO
{
	public class Feedback
	{
        public int Id { get; set; }
        public string Date { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public int? Rate { get; set; }
    }
}

